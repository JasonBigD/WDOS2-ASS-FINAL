const randomNum = Math.floor(Math.random() * 101) + 1;

let inputNum = document.getElementById("input");

function guessFunction() {
    let guessNum = input.value;

    if (guessNum == randomNum) {
        document.getElementById("message").innerHTML = guessNum + " is correct!";
        document.getElementById("message").style.backgroundColor = "green";
        EmptyScreen();
    }

    else if ((0 < guessNum - randomNum) && (guessNum - randomNum <= 10)) {
        document.getElementById("message").innerHTML = guessNum + " is high. But pretty close!";
        document.getElementById("message").style.backgroundColor = "red";
        EmptyScreen();
    }

    else if (guessNum - randomNum > 30) {
        document.getElementById("message").innerHTML = guessNum + " is too high! Again!";
        document.getElementById("message").style.backgroundColor = "blue";
        EmptyScreen();
    }

    else if ((0 < randomNum - guessNum) && (randomNum - guessNum <= 10)) {
        document.getElementById("message").innerHTML = guessNum + " is low. But pretty close!";
        document.getElementById("message").style.backgroundColor = "red";
        EmptyScreen();
    }

    else if (randomNum - guessNum > 30) {
        document.getElementById("message").innerHTML = guessNum + " is too low! Again!";
        document.getElementById("message").style.backgroundColor = "blue";
        EmptyScreen();
    }

    else {
        document.getElementById("message").style.backgroundColor = "white";
        EmptyScreen();
    }
}

function EmptyScreen() {
    let emptyNum = document.getElementById("input");
    if (emptyNum.value != " ") {
        emptyNum.value = " ";
    }
}

function restartFunction() {
    location.reload(true);
}
